/**
 * 数据文件（熊市关卡特供新闻 —— 2008 金融危机）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 *
 * 开年第一条 —— 熊市定调：全球危机、指数腰斩。
 */

export default {
  "id": "bl_n_001",
  "turn": 1,
  "source": "财经头条",
  "headline": "次贷危机蔓延，全球股市集体重挫",
  "body": "美国次贷危机持续发酵，隔夜美股暴跌，亚太股市全线低开。机构普遍下调全年盈利预期，市场弥漫悲观情绪。",
  "target": "600519",
  "link": "macro",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": -3.8,
    "turns": 2
  }
};
