/**
 * 数据文件（由 n_001.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_001",
  "turn": 1,
  "source": "证券日报",
  "headline": "白酒板块迎春节备货旺季，渠道打款积极",
  "body": "多家经销商反馈，高端白酒春节前备货量同比增长…",
  "target": "600519",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.2,
    "turns": 2
  }
};
