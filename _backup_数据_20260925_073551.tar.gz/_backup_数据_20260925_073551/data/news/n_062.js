/**
 * 数据文件（由 n_062.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_062",
  "turn": 11,
  "source": "酒业观察",
  "headline": "白酒行业进入旺季，动销持续改善",
  "body": "行业进入传统旺季，动销数据改善…",
  "target": "600519",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.0,
    "turns": 2
  }
};
