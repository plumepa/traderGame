/**
 * 数据文件（由 n_029.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_029",
  "turn": 5,
  "source": "电池中国",
  "headline": "宁德时代海外订单占比提升至 35%",
  "body": "公司披露海外业务进展…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
