/**
 * 数据文件（由 n_061.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_061",
  "turn": 11,
  "source": "证券日报",
  "headline": "贵州茅台年度业绩预告超出市场预期",
  "body": "公司发布业绩预告，净利增速超预期…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 4.2,
    "turns": 2
  }
};
