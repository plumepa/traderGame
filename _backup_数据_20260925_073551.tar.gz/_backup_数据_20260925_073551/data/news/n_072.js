/**
 * 数据文件（由 n_072.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_072",
  "turn": 12,
  "source": "海外传言",
  "headline": "传：海外对华电池加征关税",
  "body": "市场传闻海外将对华电池产品加征关税…",
  "target": "300750",
  "link": "macro",
  "truth": false,
  "credibility": 0.25,
  "impact": {
    "drift": -5.2,
    "turns": 2
  }
};
