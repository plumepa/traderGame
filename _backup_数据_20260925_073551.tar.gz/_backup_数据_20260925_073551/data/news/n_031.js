/**
 * 数据文件（由 n_031.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_031",
  "turn": 6,
  "source": "消费日报",
  "headline": "传：白酒行业将出台限价政策",
  "body": "市场传闻有关部门将规范高端白酒定价…",
  "target": "600519",
  "link": "industry",
  "truth": false,
  "credibility": 0.25,
  "impact": {
    "drift": -5.2,
    "turns": 2
  }
};
