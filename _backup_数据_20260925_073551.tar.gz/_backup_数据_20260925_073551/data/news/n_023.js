/**
 * 数据文件（由 n_023.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_023",
  "turn": 4,
  "source": "产业政策网",
  "headline": "工信部发文支持新型储能发展",
  "body": "政策明确支持储能技术研发与产业化…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 4.2,
    "turns": 2
  }
};
