/**
 * 数据文件（由 n_017.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_017",
  "turn": 3,
  "source": "新能源内参",
  "headline": "宁德时代与国内车企签订三年供货框架协议",
  "body": "公司公告称已与某头部车企达成合作…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 3.8,
    "turns": 2
  }
};
