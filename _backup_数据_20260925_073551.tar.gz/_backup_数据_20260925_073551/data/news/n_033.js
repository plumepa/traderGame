/**
 * 数据文件（由 n_033.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_033",
  "turn": 6,
  "source": "地产金融报",
  "headline": "万科 A 完成 20 亿中期票据发行",
  "body": "公司成功发行中期票据，融资成本下降…",
  "target": "000002",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 2.8,
    "turns": 2
  }
};
