/**
 * 数据文件（由 n_065.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_065",
  "turn": 11,
  "source": "能源瞭望",
  "headline": "全球储能招标量大幅增长",
  "body": "海外储能招标数据显示需求旺盛…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 4.0,
    "turns": 2
  }
};
