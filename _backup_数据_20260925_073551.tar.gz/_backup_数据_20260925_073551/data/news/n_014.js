/**
 * 数据文件（由 n_014.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_014",
  "turn": 3,
  "source": "证券日报",
  "headline": "贵州茅台获北向资金连续增持",
  "body": "陆股通数据显示，北向资金已连续多日净买入…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.1,
    "turns": 2
  }
};
