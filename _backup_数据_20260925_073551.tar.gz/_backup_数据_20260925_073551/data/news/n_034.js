/**
 * 数据文件（由 n_034.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_034",
  "turn": 6,
  "source": "地产观察",
  "headline": "一线城市二手房成交回暖，地产链条修复",
  "body": "高频数据显示二手房成交环比改善…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.4,
    "turns": 2
  }
};
