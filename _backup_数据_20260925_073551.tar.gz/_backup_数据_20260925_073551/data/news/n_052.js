/**
 * 数据文件（由 n_052.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_052",
  "turn": 9,
  "source": "地产金融报",
  "headline": "房企并购贷款支持力度加大",
  "body": "金融机构对优质房企并购给予支持…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.2,
    "turns": 2
  }
};
