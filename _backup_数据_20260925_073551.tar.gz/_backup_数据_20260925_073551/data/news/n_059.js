/**
 * 数据文件（由 n_059.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_059",
  "turn": 10,
  "source": "产业政策网",
  "headline": "传：新能源车购置税优惠将取消",
  "body": "市场传闻购置税优惠政策将提前退出…",
  "target": "300750",
  "link": "industry",
  "truth": false,
  "credibility": 0.3,
  "impact": {
    "drift": -5.0,
    "turns": 2
  }
};
