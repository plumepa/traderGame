/**
 * 数据文件（由 n_020.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_020",
  "turn": 4,
  "source": "消费日报",
  "headline": "传：高端白酒消费税将上调",
  "body": "市场传闻消费税改革方案涉及高端白酒…",
  "target": "600519",
  "link": "industry",
  "truth": false,
  "credibility": 0.3,
  "impact": {
    "drift": -4.6,
    "turns": 2
  }
};
