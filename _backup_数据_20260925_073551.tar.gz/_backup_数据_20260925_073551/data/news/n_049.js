/**
 * 数据文件（由 n_049.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_049",
  "turn": 9,
  "source": "消费日报",
  "headline": "白酒板块估值处于历史低位，资金关注度提升",
  "body": "板块估值回落至历史低位区间…",
  "target": "600519",
  "link": "industry",
  "truth": true,
  "credibility": 0.75,
  "impact": {
    "drift": 2.8,
    "turns": 2
  }
};
