/**
 * 数据文件（由 n_009.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_009",
  "turn": 2,
  "source": "地产观察",
  "headline": "多地放松限购，楼市成交边际回暖",
  "body": "部分二线城市放宽限购政策，周度成交环比改善…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.8,
    "turns": 2
  }
};
