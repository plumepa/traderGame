/**
 * 数据文件（由 n_012.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_012",
  "turn": 2,
  "source": "市场传闻",
  "headline": "传：新能源车补贴退坡传闻再起",
  "body": "有关部门或调整新能源车购置补贴标准…",
  "target": "300750",
  "link": "industry",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
