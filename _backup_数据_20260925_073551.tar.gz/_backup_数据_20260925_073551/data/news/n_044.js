/**
 * 数据文件（由 n_044.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_044",
  "turn": 8,
  "source": "酒业观察",
  "headline": "贵州茅台年度经销商大会释放利好",
  "body": "公司在经销商大会上公布明年规划…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
