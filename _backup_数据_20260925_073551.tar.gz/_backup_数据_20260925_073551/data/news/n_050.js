/**
 * 数据文件（由 n_050.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_050",
  "turn": 9,
  "source": "证券时报",
  "headline": "贵州茅台获多家机构调研",
  "body": "近期有数十家机构前往公司调研…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 2.6,
    "turns": 2
  }
};
