/**
 * 数据文件（由 n_013.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_013",
  "turn": 3,
  "source": "消费日报",
  "headline": "白酒行业库存高企，部分中小品牌降价促销",
  "body": "渠道调研显示行业库存处于历史高位…",
  "target": "600519",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": -2.2,
    "turns": 2
  }
};
