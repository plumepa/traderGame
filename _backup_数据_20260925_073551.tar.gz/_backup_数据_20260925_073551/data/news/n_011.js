/**
 * 数据文件（由 n_011.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_011",
  "turn": 2,
  "source": "电池中国",
  "headline": "宁德时代发布新一代储能电池，能量密度提升 30%",
  "body": "公司在技术发布会上公布新品…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": -1.2,
    "turns": 2
  }
};
