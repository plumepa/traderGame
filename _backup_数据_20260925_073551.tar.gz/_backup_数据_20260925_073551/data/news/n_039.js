/**
 * 数据文件（由 n_039.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_039",
  "turn": 7,
  "source": "市场传闻",
  "headline": "传：房地产税试点将全面推开",
  "body": "市场传闻房地产税试点城市将大幅扩容…",
  "target": "000002",
  "link": "industry",
  "truth": false,
  "credibility": 0.25,
  "impact": {
    "drift": -5.5,
    "turns": 2
  }
};
