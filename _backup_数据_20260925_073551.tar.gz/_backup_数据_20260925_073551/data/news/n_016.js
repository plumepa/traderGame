/**
 * 数据文件（由 n_016.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_016",
  "turn": 3,
  "source": "市场传闻",
  "headline": "传：万科 A 债务违约风险上升",
  "body": "市场传闻公司某笔债券存在兑付压力…",
  "target": "000002",
  "link": "direct",
  "truth": false,
  "credibility": 0.25,
  "impact": {
    "drift": -5.8,
    "turns": 2
  }
};
