/**
 * 数据文件（由 n_048.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_048",
  "turn": 8,
  "source": "产业政策网",
  "headline": "新型储能装机量同比翻倍",
  "body": "行业数据显示储能装机增长迅猛…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 4.4,
    "turns": 2
  }
};
