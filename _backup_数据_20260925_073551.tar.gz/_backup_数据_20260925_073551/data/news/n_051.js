/**
 * 数据文件（由 n_051.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_051",
  "turn": 9,
  "source": "小道消息",
  "headline": "传：万科 A 将进行大规模裁员",
  "body": "市场传闻公司将大幅裁减员工规模…",
  "target": "000002",
  "link": "direct",
  "truth": false,
  "credibility": 0.2,
  "impact": {
    "drift": -5.4,
    "turns": 2
  }
};
