/**
 * 数据文件（由 n_069.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_069",
  "turn": 12,
  "source": "地产观察",
  "headline": "万科 A 年末冲刺销售，单月数据亮眼",
  "body": "公司单月销售数据表现亮眼…",
  "target": "000002",
  "link": "direct",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.2,
    "turns": 2
  }
};
