/**
 * 数据文件（由 n_068.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_068",
  "turn": 12,
  "source": "酒业观察",
  "headline": "贵州茅台获纳入多个重要指数",
  "body": "公司将纳入多个重要指数成分股…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.0,
    "turns": 2
  }
};
