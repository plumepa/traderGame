/**
 * 数据文件（由 n_004.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_004",
  "turn": 1,
  "source": "财经时报",
  "headline": "万科 A 年报预披露，销售面积同比下滑",
  "body": "公司全年销售面积同比下降，去化压力仍在…",
  "target": "000002",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": -3.6,
    "turns": 2
  }
};
