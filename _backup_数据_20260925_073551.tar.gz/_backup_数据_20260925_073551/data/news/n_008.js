/**
 * 数据文件（由 n_008.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_008",
  "turn": 2,
  "source": "经济参考报",
  "headline": "高端消费承压，白酒精英化趋势延续",
  "body": "宏观数据显示高端消费增速放缓…",
  "target": "600519",
  "link": "macro",
  "truth": true,
  "credibility": 0.7,
  "impact": {
    "drift": -2.4,
    "turns": 2
  }
};
