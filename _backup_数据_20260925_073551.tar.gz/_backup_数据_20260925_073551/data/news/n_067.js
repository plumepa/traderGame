/**
 * 数据文件（由 n_067.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_067",
  "turn": 12,
  "source": "市场传闻",
  "headline": "传：白酒板块年末行情启动，资金回流",
  "body": "年末资金回流消费板块…",
  "target": "600519",
  "link": "industry",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": 3.4,
    "turns": 2
  }
};
