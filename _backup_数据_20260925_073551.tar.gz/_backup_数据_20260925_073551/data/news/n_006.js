/**
 * 数据文件（由 n_006.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_006",
  "turn": 1,
  "source": "新能源内参",
  "headline": "传：宁德时代获欧洲车企百亿订单",
  "body": "据知情人士透露，公司将与某欧洲车企签订长期供货协议…",
  "target": "300750",
  "link": "direct",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": 5.1,
    "turns": 2
  }
};
