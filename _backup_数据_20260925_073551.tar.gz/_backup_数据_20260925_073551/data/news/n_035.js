/**
 * 数据文件（由 n_035.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_035",
  "turn": 6,
  "source": "产业政策网",
  "headline": "新能源汽车下乡政策扩大实施范围",
  "body": "政策将覆盖更多县域市场…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.2,
    "turns": 2
  }
};
