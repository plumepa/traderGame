/**
 * 数据文件（由 n_046.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_046",
  "turn": 8,
  "source": "地产观察",
  "headline": "保交楼政策加码，房企资金压力缓解",
  "body": "政策层面继续支持保交楼…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.3,
    "turns": 2
  }
};
