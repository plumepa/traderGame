/**
 * 数据文件（由 n_005.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_005",
  "turn": 1,
  "source": "能源瞭望",
  "headline": "碳酸锂价格企稳回升，电池成本压力缓解",
  "body": "碳酸锂现货价格连续两周上行…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.75,
  "impact": {
    "drift": 3.4,
    "turns": 2
  }
};
