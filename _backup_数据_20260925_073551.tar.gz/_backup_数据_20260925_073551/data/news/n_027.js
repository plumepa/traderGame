/**
 * 数据文件（由 n_027.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_027",
  "turn": 5,
  "source": "央行公告",
  "headline": "LPR 下调 10 个基点，房贷成本进一步降低",
  "body": "5 年期以上 LPR 下调 10bp…",
  "target": "000002",
  "link": "macro",
  "truth": true,
  "credibility": 0.95,
  "impact": {
    "drift": 2.4,
    "turns": 2
  }
};
