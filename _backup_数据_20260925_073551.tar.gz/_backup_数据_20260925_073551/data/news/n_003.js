/**
 * 数据文件（由 n_003.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_003",
  "turn": 1,
  "source": "央行公告",
  "headline": "央行降准 0.5 个百分点，释放长期资金",
  "body": "此次降准将释放约万亿长期流动性…",
  "target": "000002",
  "link": "macro",
  "truth": true,
  "credibility": 0.95,
  "impact": {
    "drift": 2.8,
    "turns": 2
  }
};
