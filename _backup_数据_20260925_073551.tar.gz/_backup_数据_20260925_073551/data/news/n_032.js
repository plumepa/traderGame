/**
 * 数据文件（由 n_032.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_032",
  "turn": 6,
  "source": "酒业观察",
  "headline": "贵州茅台三季报净利同比增长 15%",
  "body": "公司三季报业绩稳健…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 3.8,
    "turns": 2
  }
};
