/**
 * 数据文件（由 n_060.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_060",
  "turn": 10,
  "source": "新能源内参",
  "headline": "宁德时代发布三季报，储能出货量创新高",
  "body": "公司储能业务出货量创单季新高…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
