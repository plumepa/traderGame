/**
 * 数据文件（由 n_002.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_002",
  "turn": 1,
  "source": "酒业观察",
  "headline": "传：贵州茅台将提价 10%",
  "body": "市场传闻公司将于下月调整出厂价，幅度约 10%…",
  "target": "600519",
  "link": "direct",
  "truth": false,
  "credibility": 0.4,
  "impact": {
    "drift": 4.5,
    "turns": 2
  }
};
