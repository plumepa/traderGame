/**
 * 数据文件（由 n_036.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_036",
  "turn": 6,
  "source": "新能源内参",
  "headline": "传：宁德时代核心技术人员离职",
  "body": "市场传闻公司技术团队出现变动…",
  "target": "300750",
  "link": "direct",
  "truth": false,
  "credibility": 0.3,
  "impact": {
    "drift": -4.4,
    "turns": 2
  }
};
