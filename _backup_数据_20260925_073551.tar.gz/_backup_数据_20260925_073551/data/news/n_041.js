/**
 * 数据文件（由 n_041.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_041",
  "turn": 7,
  "source": "电池中国",
  "headline": "宁德时代获国际认证，产品进入北美市场",
  "body": "公司产品通过北美市场认证…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 4.1,
    "turns": 2
  }
};
