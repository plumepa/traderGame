/**
 * 数据文件（由 n_028.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_028",
  "turn": 5,
  "source": "市场传闻",
  "headline": "传：万科 A 拟出售部分商业地产资产",
  "body": "市场传闻公司计划处置部分持有型物业…",
  "target": "000002",
  "link": "direct",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": -2.8,
    "turns": 2
  }
};
