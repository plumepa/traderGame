/**
 * 数据文件（由 n_022.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_022",
  "turn": 4,
  "source": "地产金融报",
  "headline": "房企融资环境边际改善，多家公司发债成功",
  "body": "近期多家房企完成境内债券发行…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.75,
  "impact": {
    "drift": 2.6,
    "turns": 2
  }
};
