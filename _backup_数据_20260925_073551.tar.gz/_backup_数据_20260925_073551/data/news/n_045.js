/**
 * 数据文件（由 n_045.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_045",
  "turn": 8,
  "source": "地产金融报",
  "headline": "万科 A 前三季度营收降幅收窄",
  "body": "公司经营数据显示降幅环比收窄…",
  "target": "000002",
  "link": "direct",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 2.4,
    "turns": 2
  }
};
