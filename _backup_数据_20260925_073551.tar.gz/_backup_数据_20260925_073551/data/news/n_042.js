/**
 * 数据文件（由 n_042.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_042",
  "turn": 7,
  "source": "能源瞭望",
  "headline": "全球锂电需求增速放缓，行业竞争加剧",
  "body": "研究机构下调全球锂电需求增速预期…",
  "target": "300750",
  "link": "industry",
  "truth": true,
  "credibility": 0.75,
  "impact": {
    "drift": -3.1,
    "turns": 2
  }
};
