/**
 * 数据文件（由 n_071.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_071",
  "turn": 12,
  "source": "新能源内参",
  "headline": "宁德时代海外产能释放，出口占比提升",
  "body": "公司海外产能陆续投产…",
  "target": "300750",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.8,
    "turns": 2
  }
};
