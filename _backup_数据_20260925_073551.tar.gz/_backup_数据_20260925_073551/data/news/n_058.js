/**
 * 数据文件（由 n_058.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_058",
  "turn": 10,
  "source": "央行公告",
  "headline": "央行表态支持房地产市场平稳发展",
  "body": "央行在货币政策报告中提及房地产…",
  "target": "000002",
  "link": "macro",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 3.4,
    "turns": 2
  }
};
