/**
 * 数据文件（由 n_070.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_070",
  "turn": 12,
  "source": "地产金融报",
  "headline": "地产政策持续宽松，行业预期修复",
  "body": "多部门继续释放地产支持信号…",
  "target": "000002",
  "link": "industry",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 3.5,
    "turns": 2
  }
};
