/**
 * 数据文件（由 n_047.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_047",
  "turn": 8,
  "source": "股吧传言",
  "headline": "传：宁德时代储能业务亏损扩大",
  "body": "市场传闻公司储能板块盈利能力下滑…",
  "target": "300750",
  "link": "direct",
  "truth": false,
  "credibility": 0.3,
  "impact": {
    "drift": -4.2,
    "turns": 2
  }
};
