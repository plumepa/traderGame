/**
 * 数据文件（由 n_043.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_043",
  "turn": 8,
  "source": "市场传闻",
  "headline": "传：消费复苏数据超预期，白酒受益",
  "body": "社零数据显示消费复苏好于预期…",
  "target": "600519",
  "link": "macro",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": 3.2,
    "turns": 2
  }
};
