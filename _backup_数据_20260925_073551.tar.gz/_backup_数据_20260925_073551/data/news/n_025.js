/**
 * 数据文件（由 n_025.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_025",
  "turn": 5,
  "source": "证券时报",
  "headline": "贵州茅台中报预增，机构上调目标价",
  "body": "多家券商发布研报上调公司目标价…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 4.5,
    "turns": 2
  }
};
