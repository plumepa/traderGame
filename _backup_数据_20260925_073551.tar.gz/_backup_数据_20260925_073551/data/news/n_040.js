/**
 * 数据文件（由 n_040.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_040",
  "turn": 7,
  "source": "地产观察",
  "headline": "万科 A 管理层增持公司股份",
  "body": "公司公告称管理层以自有资金增持…",
  "target": "000002",
  "link": "direct",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
