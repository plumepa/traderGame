/**
 * 数据文件（由 n_054.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_054",
  "turn": 9,
  "source": "市场传闻",
  "headline": "传：电池原材料价格波动加剧，成本端不确定性上升",
  "body": "原材料价格近期波动幅度加大…",
  "target": "300750",
  "link": "industry",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": -2.9,
    "turns": 2
  }
};
