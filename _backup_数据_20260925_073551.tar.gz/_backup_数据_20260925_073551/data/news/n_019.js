/**
 * 数据文件（由 n_019.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_019",
  "turn": 4,
  "source": "酒业观察",
  "headline": "贵州茅台股东大会释放积极信号",
  "body": "管理层表示将保持稳健增长…",
  "target": "600519",
  "link": "direct",
  "truth": true,
  "credibility": 0.85,
  "impact": {
    "drift": 2.8,
    "turns": 2
  }
};
