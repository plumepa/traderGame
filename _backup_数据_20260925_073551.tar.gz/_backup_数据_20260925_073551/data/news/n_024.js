/**
 * 数据文件（由 n_024.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_024",
  "turn": 4,
  "source": "小道消息",
  "headline": "传：宁德时代海外工厂投产延期",
  "body": "据供应链消息，公司海外工厂进度不及预期…",
  "target": "300750",
  "link": "direct",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": -4.8,
    "turns": 2
  }
};
