/**
 * 数据文件（由 n_026.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_026",
  "turn": 5,
  "source": "经济参考报",
  "headline": "白酒动销改善，中秋国庆双节备货启动",
  "body": "渠道反馈双节备货节奏好于去年同期…",
  "target": "600519",
  "link": "industry",
  "truth": true,
  "credibility": 0.8,
  "impact": {
    "drift": 3.3,
    "turns": 2
  }
};
