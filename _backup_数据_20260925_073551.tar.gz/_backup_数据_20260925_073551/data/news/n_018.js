/**
 * 数据文件（由 n_018.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_018",
  "turn": 3,
  "source": "市场传闻",
  "headline": "传：锂矿供给过剩，碳酸锂价格持续走低",
  "body": "海外锂矿新增产能陆续投放…",
  "target": "300750",
  "link": "industry",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": -3.2,
    "turns": 2
  }
};
