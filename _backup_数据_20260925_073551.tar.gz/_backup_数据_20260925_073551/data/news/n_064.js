/**
 * 数据文件（由 n_064.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_064",
  "turn": 11,
  "source": "市场传闻",
  "headline": "传：房地产融资白名单将扩容",
  "body": "市场传闻融资白名单房企数量将扩大…",
  "target": "000002",
  "link": "industry",
  "truth": false,
  "credibility": 0.35,
  "impact": {
    "drift": 3.6,
    "turns": 2
  }
};
