/**
 * 数据文件（由 n_015.json 转换而来）
 *
 * 为什么是 .js 而不是 .json？
 * 微信小游戏的打包器不支持 import JSON —— 它会把路径当模块名
 * 自动补 .js 后缀，去找 "xxx.json.js" 从而报错。
 * 因此数据一律以 .js 模块形式导出。
 */

export default {
  "id": "n_015",
  "turn": 3,
  "source": "金融时报",
  "headline": "房贷利率下调，首套房贷平均利率创新低",
  "body": "多地首套房贷利率已降至历史低位…",
  "target": "000002",
  "link": "macro",
  "truth": true,
  "credibility": 0.9,
  "impact": {
    "drift": 3.4,
    "turns": 2
  }
};
