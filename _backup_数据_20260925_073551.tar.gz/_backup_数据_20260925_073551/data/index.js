/**
 * 数据注册表 —— 显式 import 所有实体并汇总
 *
 * ⚠️ 两个平台约束决定了本文件必须手写注册：
 *
 * 1. 微信小游戏没有读取工程源码目录的文件系统能力 ——
 *    wx.getFileSystemManager() 只能操作【用户数据目录】，
 *    无法 readdir 打包进来的 data/ 目录。所以不能自动遍历。
 *
 * 2. 打包器不支持 import JSON —— 会把 "xxx.json" 当模块名
 *    自动补 .js 后缀去找 "xxx.json.js"，从而报错。
 *    因此数据文件一律是 .js 模块（export default {...}）。
 *
 * 新增实体时，在下方补一行 import 与一处数组元素即可。
 */

// ============ 股票 ============
import stock_000002 from './stocks/000002';
import stock_300750 from './stocks/300750';
import stock_600519 from './stocks/600519';

// ============ 关卡 ============
import level_lv_01 from './levels/lv_01';

import { INSTITUTIONS, institutionOf } from './institutions';

// ============ 股票汇总 ============
export const STOCKS = [stock_000002, stock_300750, stock_600519];

export const STOCK_MAP = STOCKS.reduce((acc, s) => {
  acc[s.code] = s;
  return acc;
}, {});

// ============ 新闻 ============
// 共 72 条
import n_001 from './news/n_001';
import n_002 from './news/n_002';
import n_003 from './news/n_003';
import n_004 from './news/n_004';
import n_005 from './news/n_005';
import n_006 from './news/n_006';
import n_007 from './news/n_007';
import n_008 from './news/n_008';
import n_009 from './news/n_009';
import n_010 from './news/n_010';
import n_011 from './news/n_011';
import n_012 from './news/n_012';
import n_013 from './news/n_013';
import n_014 from './news/n_014';
import n_015 from './news/n_015';
import n_016 from './news/n_016';
import n_017 from './news/n_017';
import n_018 from './news/n_018';
import n_019 from './news/n_019';
import n_020 from './news/n_020';
import n_021 from './news/n_021';
import n_022 from './news/n_022';
import n_023 from './news/n_023';
import n_024 from './news/n_024';
import n_025 from './news/n_025';
import n_026 from './news/n_026';
import n_027 from './news/n_027';
import n_028 from './news/n_028';
import n_029 from './news/n_029';
import n_030 from './news/n_030';
import n_031 from './news/n_031';
import n_032 from './news/n_032';
import n_033 from './news/n_033';
import n_034 from './news/n_034';
import n_035 from './news/n_035';
import n_036 from './news/n_036';
import n_037 from './news/n_037';
import n_038 from './news/n_038';
import n_039 from './news/n_039';
import n_040 from './news/n_040';
import n_041 from './news/n_041';
import n_042 from './news/n_042';
import n_043 from './news/n_043';
import n_044 from './news/n_044';
import n_045 from './news/n_045';
import n_046 from './news/n_046';
import n_047 from './news/n_047';
import n_048 from './news/n_048';
import n_049 from './news/n_049';
import n_050 from './news/n_050';
import n_051 from './news/n_051';
import n_052 from './news/n_052';
import n_053 from './news/n_053';
import n_054 from './news/n_054';
import n_055 from './news/n_055';
import n_056 from './news/n_056';
import n_057 from './news/n_057';
import n_058 from './news/n_058';
import n_059 from './news/n_059';
import n_060 from './news/n_060';
import n_061 from './news/n_061';
import n_062 from './news/n_062';
import n_063 from './news/n_063';
import n_064 from './news/n_064';
import n_065 from './news/n_065';
import n_066 from './news/n_066';
import n_067 from './news/n_067';
import n_068 from './news/n_068';
import n_069 from './news/n_069';
import n_070 from './news/n_070';
import n_071 from './news/n_071';
import n_072 from './news/n_072';

export const NEWS = [
  n_001, n_002, n_003, n_004, n_005, n_006, n_007, n_008, n_009, n_010,
  n_011, n_012, n_013, n_014, n_015, n_016, n_017, n_018, n_019, n_020,
  n_021, n_022, n_023, n_024, n_025, n_026, n_027, n_028, n_029, n_030,
  n_031, n_032, n_033, n_034, n_035, n_036, n_037, n_038, n_039, n_040,
  n_041, n_042, n_043, n_044, n_045, n_046, n_047, n_048, n_049, n_050,
  n_051, n_052, n_053, n_054, n_055, n_056, n_057, n_058, n_059, n_060,
  n_061, n_062, n_063, n_064, n_065, n_066, n_067, n_068, n_069, n_070,
  n_071, n_072,
];

export const NEWS_MAP = NEWS.reduce((acc, n) => {
  acc[n.id] = n;
  return acc;
}, {});

// ============ 关卡汇总 ============
export const LEVELS = [level_lv_01];

export const LEVEL_MAP = LEVELS.reduce((acc, l) => {
  acc[l.id] = l;
  return acc;
}, {});

// ============ 机构 ============
export { INSTITUTIONS, institutionOf };

/**
 * 数据自检 —— 启动时调用，尽早发现数据错误
 * @returns {string[]} 错误信息列表，空数组表示全部通过
 */
export function validateData() {
  const errors = [];

  // 1. 股票路径长度必须等于关卡回合数
  const turnLen = LEVELS.length ? LEVELS[0].turns : 12;
  STOCKS.forEach((s) => {
    if (!Array.isArray(s.path) || s.path.length !== turnLen) {
      errors.push(`股票 ${s.code} 的 path 长度应为 ${turnLen}，实际 ${s.path ? s.path.length : 'null'}`);
    }
    if (typeof s.basePrice !== 'number' || s.basePrice <= 0) {
      errors.push(`股票 ${s.code} 的 basePrice 非法: ${s.basePrice}`);
    }
    if (typeof s.floor !== 'number' || s.floor <= 0) {
      errors.push(`股票 ${s.code} 的 floor 非法: ${s.floor}`);
    }
  });

  // 2. 关卡股票数与行业唯一性
  LEVELS.forEach((lv) => {
    if (lv.stocks.length !== 3) {
      errors.push(`关卡 ${lv.id} 应有 3 只股票，实际 ${lv.stocks.length}`);
    }
    const industries = lv.stocks.map((code) => STOCK_MAP[code] && STOCK_MAP[code].industry);
    if (industries.some((i) => !i)) {
      errors.push(`关卡 ${lv.id} 引用了不存在的股票: ${lv.stocks.join('/')}`);
    } else if (new Set(industries).size !== industries.length) {
      errors.push(`关卡 ${lv.id} 的三只股票行业重复: ${industries.join('/')}`);
    }

    // 3. newsDeck 长度必须等于 turns
    if (lv.newsDeck.length !== lv.turns) {
      errors.push(`关卡 ${lv.id} 的 newsDeck 有 ${lv.newsDeck.length} 组，应为 ${lv.turns} 组`);
    }

    // 4. 每条新闻的 target 必须属于本关股票
    lv.newsDeck.forEach((group, gi) => {
      group.forEach((nid) => {
        const news = NEWS_MAP[nid];
        if (!news) {
          errors.push(`关卡 ${lv.id} 第 ${gi + 1} 组引用了不存在的新闻 ${nid}`);
        } else if (!lv.stocks.includes(news.target)) {
          errors.push(`新闻 ${nid} 的 target=${news.target} 不属于本关股票`);
        }
      });
    });
  });

  return errors;
}
